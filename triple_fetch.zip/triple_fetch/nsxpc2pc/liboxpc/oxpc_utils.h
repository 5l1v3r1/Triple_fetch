#ifndef _oxpc_utils_h
#define _oxpc_utils_h

void ERROR(
  const char* msg);

uint32_t
round_up_32(
  uint32_t base,
  uint32_t unit);

#endif
