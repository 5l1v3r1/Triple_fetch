#ifndef patch_amfid_h
#define patch_amfid_h

#include <mach/mach.h>

void patch_amfid(mach_port_t amfid_task_port);

#endif
